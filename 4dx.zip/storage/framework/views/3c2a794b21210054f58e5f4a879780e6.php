<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan Bulanan LM</title>
</head>
<body>
    <?php echo $__env->make('exports.lm_report_table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH D:\Layang\4dx\resources\views/exports/lm_report.blade.php ENDPATH**/ ?>